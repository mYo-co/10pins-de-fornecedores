TEMPLATE LIQUID GLASS LUXURY — 10 PINS DE MODA

Estrutura:
- index.html
- assets/modelo-1.jpeg ... modelo-4.jpeg
- assets/video-1.mp4 e video-2.mp4

O index e a pasta assets devem permanecer juntos.
Checkout usado nos CTAs: https://checkout.escalepay.com/1605547
